---
id: channel_linkedin
name: "LinkedIn"
status: draft
owner: vitaly
created_at: 2026-04-18
updated_at: 2026-04-18
channel_type: social
external_url: null
---

# LinkedIn

## Purpose

Professional public build updates.

## Audience

TODO

## Format rules

TODO

## Manual publication steps

1. Finalize the channel variant in `public/posts/`.
2. Publish manually.
3. Record publication receipt in `public/publications/`.
4. Add metrics snapshot manually when useful.

## Metrics to collect

- impressions
- reactions
- comments
- shares
- followers
