/* globals React, ERAS, ENTRIES, SURVIVAL */
const { useState, useEffect, useRef, useCallback } = React;

/* ─── PORCUPINE MASCOT ───────────────────────────────────────────────────── */
function Porcupine({ size = 180, dim = false }) {
  const o = dim ? 0.4 : 1;
  return (
    <svg width={size} height={size * 0.85} viewBox="0 0 160 136" fill="none"
      xmlns="http://www.w3.org/2000/svg" style={{ opacity: o, display: 'block' }}>
      {/* quills – back row */}
      <polygon points="120,72 130,28 138,74" fill="#22202b" stroke="#ff48a1" strokeWidth="1.5"/>
      <polygon points="108,65 122,18 130,67" fill="#22202b" stroke="#ff48a1" strokeWidth="1.5"/>
      <polygon points="95,60 112,10 120,63" fill="#22202b" stroke="#a6a396" strokeWidth="1"/>
      <polygon points="82,57 100,5 108,60" fill="#22202b" stroke="#ff48a1" strokeWidth="1.5"/>
      <polygon points="70,58 86,8 94,61" fill="#22202b" stroke="#a6a396" strokeWidth="1"/>
      <polygon points="58,61 72,14 80,63" fill="#22202b" stroke="#ff48a1" strokeWidth="1.5"/>
      <polygon points="48,66 60,22 68,68" fill="#22202b" stroke="#a6a396" strokeWidth="1"/>
      {/* body */}
      <ellipse cx="85" cy="92" rx="56" ry="34" fill="#1a1828"/>
      <ellipse cx="85" cy="92" rx="56" ry="34" fill="none" stroke="#34323f" strokeWidth="1.5"/>
      {/* belly highlight */}
      <ellipse cx="85" cy="100" rx="38" ry="20" fill="#11101a"/>
      {/* head */}
      <ellipse cx="28" cy="86" rx="22" ry="18" fill="#1a1828" stroke="#34323f" strokeWidth="1.5"/>
      {/* snout */}
      <ellipse cx="10" cy="91" rx="8" ry="6" fill="#11101a" stroke="#34323f" strokeWidth="1"/>
      {/* nose */}
      <circle cx="4" cy="91" r="2.5" fill="#a6a396"/>
      {/* eye */}
      <circle cx="22" cy="80" r="3.5" fill="#ff48a1"/>
      <circle cx="23" cy="79" r="1.2" fill="#22202b"/>
      {/* ear */}
      <ellipse cx="32" cy="70" rx="5" ry="7" fill="#22202b" stroke="#34323f" strokeWidth="1"/>
      {/* legs */}
      <rect x="52" y="120" width="10" height="14" rx="2" fill="#11101a" stroke="#34323f" strokeWidth="1"/>
      <rect x="70" y="122" width="10" height="12" rx="2" fill="#11101a" stroke="#34323f" strokeWidth="1"/>
      <rect x="95" y="122" width="10" height="12" rx="2" fill="#11101a" stroke="#34323f" strokeWidth="1"/>
      <rect x="112" y="120" width="10" height="14" rx="2" fill="#11101a" stroke="#34323f" strokeWidth="1"/>
      {/* feet */}
      <rect x="50" y="131" width="14" height="5" rx="1" fill="#0a0912"/>
      <rect x="68" y="131" width="14" height="5" rx="1" fill="#0a0912"/>
      <rect x="93" y="131" width="14" height="5" rx="1" fill="#0a0912"/>
      <rect x="110" y="131" width="14" height="5" rx="1" fill="#0a0912"/>
      {/* tail */}
      <path d="M141 88 Q155 80 152 72 Q149 65 143 70" stroke="#34323f" strokeWidth="2" fill="none"/>
      <polygon points="141,88 148,70 155,88" fill="#11101a" stroke="#34323f" strokeWidth="1"/>
    </svg>
  );
}

/* ─── ENTRY TYPE CONFIG ──────────────────────────────────────────────────── */
const TYPE_CONFIG = {
  experiment: { label: 'EXPERIMENT', color: '#77a9ff', glyph: '⬡' },
  failure:    { label: 'FAILURE',    color: '#ff6b62', glyph: '✕' },
  artifact:   { label: 'ARTIFACT',   color: '#ffc06b', glyph: '◈' },
  insight:    { label: 'INSIGHT',    color: '#3fe38d', glyph: '◎' },
  system:     { label: 'SYSTEM',     color: '#ff48a1', glyph: '§' },
};

const STATUS_COLOR = {
  legacy:   '#6c6a5e',
  ancestor: '#f7a93b',
  pivot:    '#e8433a',
  current:  '#3fe38d',
};

/* ─── TIMELINE CARD ──────────────────────────────────────────────────────── */
function TimelineCard({ entry, isNew }) {
  const [open, setOpen] = useState(false);
  const tc = TYPE_CONFIG[entry.type] || TYPE_CONFIG.experiment;
  const survivedBg = entry.survived === false ? '#2a0a0a' : entry.survived === 'current' ? '#0a1f14' : '#1a1000';
  const survivedColor = entry.survived === false ? '#ff6b62' : entry.survived === 'current' ? '#3fe38d' : '#ffc06b';
  const survivedText = entry.survived === false ? '— dropped' : entry.survived === 'current' ? '● current' : `→ ${entry.survived}`;

  return (
    <div
      onClick={() => setOpen(o => !o)}
      style={{
        background: open ? '#11101a' : '#0a0912',
        border: `1px solid ${open ? '#34323f' : '#22202b'}`,
        borderLeft: `3px solid ${tc.color}`,
        padding: '16px 18px',
        cursor: 'pointer',
        transition: 'all 0.16s ease',
        marginBottom: 1,
        ...(isNew && { animation: 'fadeIn 0.3s ease' }),
      }}
      onMouseEnter={e => e.currentTarget.style.borderColor = '#34323f'}
      onMouseLeave={e => { if (!open) e.currentTarget.style.borderColor = '#22202b'; e.currentTarget.style.borderLeftColor = tc.color; }}
    >
      {/* header row */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 8 }}>
        <span style={{ fontFamily: 'var(--font-mono)', fontSize: 11, fontWeight: 700, letterSpacing: '0.12em', color: tc.color, textTransform: 'uppercase' }}>
          {tc.glyph} {tc.label}
        </span>
        <span style={{ fontFamily: 'var(--font-mono)', fontSize: 11, color: '#6c6a5e', marginLeft: 'auto' }}>
          #{entry.seq} · {entry.date}
        </span>
      </div>

      {/* title */}
      <div style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 17, letterSpacing: '-0.01em', color: '#ebe7da', lineHeight: 1.25, marginBottom: open ? 12 : 0 }}>
        {entry.title}
      </div>

      {/* expanded body */}
      {open && (
        <div>
          <p style={{ fontFamily: 'var(--font-mono)', fontSize: 13, lineHeight: 1.65, color: '#a6a396', margin: '0 0 12px', maxWidth: '100%' }}>
            {entry.body}
          </p>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, flexWrap: 'wrap' }}>
            <span style={{
              fontFamily: 'var(--font-mono)', fontSize: 11, fontWeight: 700,
              background: survivedBg, color: survivedColor,
              padding: '2px 8px', border: `1px solid ${survivedColor}33`,
              letterSpacing: '0.06em',
            }}>{survivedText}</span>
            {entry.tags.map(t => (
              <span key={t} style={{ fontFamily: 'var(--font-mono)', fontSize: 11, color: '#6c6a5e' }}>#{t}</span>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

/* ─── ARTIFACT CARD ──────────────────────────────────────────────────────── */
function ArtifactCard({ entry }) {
  return (
    <div style={{
      background: '#05040a',
      border: '1px solid #22202b',
      borderTop: '2px solid #ffc06b',
      padding: '14px 14px 16px',
      boxShadow: '3px 3px 0 0 #ff2e88',
      marginBottom: 20,
    }}>
      <div style={{ fontFamily: 'var(--font-mono)', fontSize: 10, fontWeight: 700, letterSpacing: '0.14em', color: '#ffc06b', marginBottom: 10, textTransform: 'uppercase' }}>
        {entry.artifactLabel || 'ARTIFACT'}
      </div>
      <pre style={{
        fontFamily: 'var(--font-mono)', fontSize: 11, lineHeight: 1.7,
        color: '#a6a396', margin: 0, whiteSpace: 'pre-wrap', wordBreak: 'break-word',
        background: 'transparent',
      }}>{entry.artifactFragment}</pre>
      <div style={{ marginTop: 10, fontFamily: 'var(--font-mono)', fontSize: 11, color: '#6c6a5e' }}>
        // {entry.title} · {entry.date}
      </div>
    </div>
  );
}

/* ─── ERA SECTION ────────────────────────────────────────────────────────── */
function EraSection({ era, entries, activeEra }) {
  const isActive = !activeEra || activeEra === era.id;
  if (!isActive) return null;
  const artifacts = entries.filter(e => e.artifact);
  const nonArtifacts = entries;

  return (
    <div id={`era-${era.id}`} style={{ marginBottom: 56 }}>
      {/* era header */}
      <div style={{
        display: 'grid', gridTemplateColumns: '1fr auto',
        alignItems: 'end', gap: 16,
        borderBottom: `2px solid ${era.color}`,
        paddingBottom: 12, marginBottom: 24,
      }}>
        <div>
          <div style={{ fontFamily: 'var(--font-mono)', fontSize: 11, fontWeight: 700, letterSpacing: '0.14em', color: era.colorBright, textTransform: 'uppercase', marginBottom: 4 }}>
            {era.statusLabel} · {era.date}
          </div>
          <div style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 28, letterSpacing: '-0.02em', color: '#ebe7da' }}>
            {era.label}
          </div>
          <div style={{ fontFamily: 'var(--font-mono)', fontSize: 13, color: '#6c6a5e', marginTop: 4, lineHeight: 1.5 }}>
            {era.desc}
          </div>
        </div>
        <div style={{
          fontFamily: 'var(--font-mono)', fontSize: 11, color: '#6c6a5e',
          textAlign: 'right', lineHeight: 1.8,
        }}>
          <div>{entries.length} entries</div>
          <div style={{ color: entries.filter(e => e.survived && e.survived !== false).length > 0 ? '#3fe38d' : '#6c6a5e' }}>
            {entries.filter(e => e.survived && e.survived !== false).length} survived
          </div>
        </div>
      </div>

      {/* two-col: cards left, artifacts right */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 280px', gap: 24, alignItems: 'start' }}>
        {/* timeline cards */}
        <div style={{ position: 'relative', paddingLeft: 20 }}>
          {/* spine */}
          <div style={{
            position: 'absolute', left: 4, top: 8, bottom: 8,
            width: 1, background: `linear-gradient(to bottom, ${era.color}88, ${era.color}22)`,
          }} />
          {nonArtifacts.map((e, i) => (
            <div key={e.id} style={{ position: 'relative', marginBottom: 2 }}>
              {/* spine dot */}
              <div style={{
                position: 'absolute', left: -20, top: 20,
                width: 7, height: 7, borderRadius: '50%',
                background: TYPE_CONFIG[e.type]?.color || '#6c6a5e',
                border: '1px solid #05040a',
              }} />
              <TimelineCard entry={e} />
            </div>
          ))}
        </div>

        {/* artifact cards */}
        <div style={{ paddingTop: 2 }}>
          {artifacts.length > 0 ? artifacts.map(e => (
            <ArtifactCard key={e.id} entry={e} />
          )) : (
            <div style={{ fontFamily: 'var(--font-mono)', fontSize: 11, color: '#34323f', padding: '16px 0', lineHeight: 1.6 }}>
              // no artifacts<br/>// for this era
            </div>
          )}
        </div>
      </div>

      {/* verdict bar */}
      <div style={{
        marginTop: 20, padding: '10px 14px',
        background: '#05040a', border: '1px solid #22202b',
        borderLeft: `3px solid ${era.color}`,
        fontFamily: 'var(--font-mono)', fontSize: 12, color: '#6c6a5e',
      }}>
        <span style={{ color: era.colorBright, fontWeight: 700 }}>VERDICT</span>
        {'  '}{era.verdict}
      </div>
    </div>
  );
}

/* ─── ERA MAP ────────────────────────────────────────────────────────────── */
function EraMap({ activeEra, onEraClick }) {
  return (
    <section style={{
      borderBottom: '1px solid #22202b',
      background: '#05040a',
    }}>
      <div style={{ maxWidth: 1240, margin: '0 auto', padding: '0 32px' }}>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(6, 1fr)' }}>
          {ERAS.map((era, i) => {
            const isActive = activeEra === era.id;
            return (
              <button key={era.id} onClick={() => onEraClick(era.id)}
                style={{
                  display: 'block', textAlign: 'left', width: '100%',
                  padding: '18px 16px 16px',
                  background: isActive ? '#11101a' : 'transparent',
                  border: 'none',
                  borderRight: i < 5 ? '1px solid #22202b' : 'none',
                  borderBottom: isActive ? `2px solid ${era.color}` : '2px solid transparent',
                  cursor: 'pointer',
                  transition: 'background 0.16s ease',
                }}
                onMouseEnter={e => { if (!isActive) e.currentTarget.style.background = '#0a0912'; }}
                onMouseLeave={e => { if (!isActive) e.currentTarget.style.background = 'transparent'; }}
              >
                <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 4 }}>
                  <div style={{ width: 6, height: 6, borderRadius: '50%', background: era.color, flexShrink: 0 }} />
                  <div style={{ fontFamily: 'var(--font-mono)', fontSize: 10, fontWeight: 700, letterSpacing: '0.12em', color: era.colorBright, textTransform: 'uppercase' }}>
                    {era.statusLabel}
                  </div>
                </div>
                <div style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 15, color: isActive ? '#ebe7da' : '#a6a396', letterSpacing: '-0.01em', marginBottom: 2 }}>
                  {era.label}
                </div>
                <div style={{ fontFamily: 'var(--font-mono)', fontSize: 11, color: '#6c6a5e' }}>
                  {era.date}
                </div>
              </button>
            );
          })}
        </div>
      </div>
    </section>
  );
}

/* ─── FILTER BAR ─────────────────────────────────────────────────────────── */
function FilterBar({ activeEra, activeTypes, onEraChange, onTypeToggle, totalVisible }) {
  const types = Object.entries(TYPE_CONFIG);
  return (
    <div style={{
      position: 'sticky', top: 0, zIndex: 100,
      background: '#05040a',
      borderBottom: '1px solid #22202b',
      backdropFilter: 'blur(8px)',
    }}>
      <div style={{
        maxWidth: 1240, margin: '0 auto', padding: '10px 32px',
        display: 'flex', alignItems: 'center', gap: 24, flexWrap: 'wrap',
      }}>
        {/* era filter */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
          <span style={{ fontFamily: 'var(--font-mono)', fontSize: 10, fontWeight: 700, letterSpacing: '0.12em', color: '#6c6a5e', textTransform: 'uppercase', marginRight: 4 }}>ERA</span>
          <button onClick={() => onEraChange(null)}
            style={{
              fontFamily: 'var(--font-mono)', fontSize: 11, fontWeight: 700,
              padding: '3px 9px', border: '1px solid',
              borderColor: !activeEra ? '#ebe7da' : '#34323f',
              background: !activeEra ? '#ebe7da' : 'transparent',
              color: !activeEra ? '#05040a' : '#6c6a5e',
              cursor: 'pointer', letterSpacing: '0.06em',
            }}>ALL</button>
          {ERAS.map(era => (
            <button key={era.id} onClick={() => onEraChange(era.id)}
              style={{
                fontFamily: 'var(--font-mono)', fontSize: 11, fontWeight: 700,
                padding: '3px 9px', border: '1px solid',
                borderColor: activeEra === era.id ? era.color : '#34323f',
                background: activeEra === era.id ? `${era.color}22` : 'transparent',
                color: activeEra === era.id ? era.colorBright : '#6c6a5e',
                cursor: 'pointer', letterSpacing: '0.06em',
              }}>{era.label}</button>
          ))}
        </div>

        <div style={{ width: 1, height: 20, background: '#22202b', flexShrink: 0 }} />

        {/* type filter */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
          <span style={{ fontFamily: 'var(--font-mono)', fontSize: 10, fontWeight: 700, letterSpacing: '0.12em', color: '#6c6a5e', textTransform: 'uppercase', marginRight: 4 }}>TYPE</span>
          {types.map(([type, cfg]) => {
            const on = activeTypes.includes(type);
            return (
              <button key={type} onClick={() => onTypeToggle(type)}
                style={{
                  fontFamily: 'var(--font-mono)', fontSize: 11, fontWeight: 700,
                  padding: '3px 9px', border: '1px solid',
                  borderColor: on ? cfg.color : '#34323f',
                  background: on ? `${cfg.color}22` : 'transparent',
                  color: on ? cfg.color : '#6c6a5e',
                  cursor: 'pointer', letterSpacing: '0.06em',
                }}>{cfg.glyph} {cfg.label}</button>
            );
          })}
        </div>

        <div style={{ flex: 1 }} />
        <span style={{ fontFamily: 'var(--font-mono)', fontSize: 11, color: '#6c6a5e' }}>
          {totalVisible} entries
        </span>
      </div>
    </div>
  );
}

/* ─── SURVIVAL MATRIX ────────────────────────────────────────────────────── */
function SurvivalMatrix() {
  return (
    <section id="survival" style={{ padding: '64px 32px', borderTop: '1px solid #22202b', background: '#05040a' }}>
      <div style={{ maxWidth: 1240, margin: '0 auto' }}>
        <div style={{ fontFamily: 'var(--font-mono)', fontSize: 11, fontWeight: 700, letterSpacing: '0.14em', color: '#6c6a5e', textTransform: 'uppercase', marginBottom: 8 }}>// what survived</div>
        <h2 style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 36, letterSpacing: '-0.02em', color: '#ebe7da', margin: '0 0 32px' }}>
          From experiment to principle.
        </h2>

        <div style={{ border: '1px solid #22202b', borderBottom: 'none' }}>
          {/* header */}
          <div style={{
            display: 'grid', gridTemplateColumns: '140px 1fr 24px 1fr 80px',
            gap: 0, borderBottom: '1px solid #ebe7da',
            background: '#11101a',
          }}>
            {['ERA', 'EXPERIMENT / FAILURE', '', '→ PUNK PRINCIPLE', 'STATUS'].map((h, i) => (
              <div key={i} style={{
                padding: '10px 14px',
                fontFamily: 'var(--font-mono)', fontSize: 10, fontWeight: 700,
                letterSpacing: '0.12em', color: '#6c6a5e', textTransform: 'uppercase',
                borderRight: i < 4 ? '1px solid #22202b' : 'none',
              }}>{h}</div>
            ))}
          </div>
          {/* rows */}
          {SURVIVAL.map((row, i) => {
            const era = ERAS.find(e => e.label === row.from);
            const isDropped = row.status === 'dropped';
            return (
              <div key={i} style={{
                display: 'grid', gridTemplateColumns: '140px 1fr 24px 1fr 80px',
                gap: 0, borderBottom: '1px solid #22202b',
                background: i % 2 === 0 ? 'transparent' : '#0a0912',
              }}>
                <div style={{ padding: '10px 14px', fontFamily: 'var(--font-mono)', fontSize: 12, color: era?.colorBright || '#a6a396', borderRight: '1px solid #22202b', display: 'flex', alignItems: 'center', gap: 6 }}>
                  <span style={{ width: 5, height: 5, borderRadius: '50%', background: era?.color || '#6c6a5e', display: 'inline-block', flexShrink: 0 }} />
                  {row.from}
                </div>
                <div style={{ padding: '10px 14px', fontFamily: 'var(--font-mono)', fontSize: 12, color: '#a6a396', borderRight: '1px solid #22202b' }}>
                  {row.experiment}
                </div>
                <div style={{ padding: '10px 4px', fontFamily: 'var(--font-mono)', fontSize: 14, color: '#34323f', borderRight: '1px solid #22202b', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>→</div>
                <div style={{ padding: '10px 14px', fontFamily: 'var(--font-mono)', fontSize: 12, color: isDropped ? '#6c6a5e' : '#ebe7da', borderRight: '1px solid #22202b', fontStyle: isDropped ? 'italic' : 'normal' }}>
                  {row.principle}
                </div>
                <div style={{ padding: '10px 14px', fontFamily: 'var(--font-mono)', fontSize: 10, fontWeight: 700, letterSpacing: '0.1em', color: isDropped ? '#ff6b62' : '#3fe38d', display: 'flex', alignItems: 'center' }}>
                  {isDropped ? '✕ DROPPED' : '● LIVE'}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}

/* ─── ARTIFACT SHELF ─────────────────────────────────────────────────────── */
function ArtifactShelf() {
  const artifacts = ENTRIES.filter(e => e.artifact);
  return (
    <section id="artifacts" style={{ padding: '64px 32px', borderTop: '1px solid #22202b', background: '#000006' }}>
      <div style={{ maxWidth: 1240, margin: '0 auto' }}>
        <div style={{ fontFamily: 'var(--font-mono)', fontSize: 11, fontWeight: 700, letterSpacing: '0.14em', color: '#6c6a5e', textTransform: 'uppercase', marginBottom: 8 }}>// artifact shelf</div>
        <h2 style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 36, letterSpacing: '-0.02em', color: '#ebe7da', margin: '0 0 8px' }}>
          Source fragments.
        </h2>
        <p style={{ fontFamily: 'var(--font-mono)', fontSize: 13, color: '#6c6a5e', margin: '0 0 36px', maxWidth: '100%' }}>
          These documents, notes, and READMEs exist in the repo. They are not summaries. They are receipts.
        </p>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 16 }}>
          {artifacts.map((e, i) => {
            const era = ERAS.find(er => er.id === e.era);
            return (
              <div key={e.id} style={{
                background: '#05040a', border: '1px solid #22202b',
                borderTop: `2px solid ${era?.color || '#6c6a5e'}`,
                padding: '14px 14px 16px',
                boxShadow: i % 3 === 0 ? '3px 3px 0 0 #ff2e88' : i % 3 === 1 ? '3px 3px 0 0 #34323f' : '3px 3px 0 0 #ffc06b33',
              }}>
                <div style={{ fontFamily: 'var(--font-mono)', fontSize: 10, fontWeight: 700, letterSpacing: '0.14em', color: era?.colorBright || '#a6a396', marginBottom: 8, textTransform: 'uppercase' }}>
                  {e.artifactLabel}
                </div>
                <pre style={{
                  fontFamily: 'var(--font-mono)', fontSize: 11, lineHeight: 1.7,
                  color: '#a6a396', margin: '0 0 10px', whiteSpace: 'pre-wrap',
                  wordBreak: 'break-word', background: 'transparent',
                }}>{e.artifactFragment}</pre>
                <div style={{ borderTop: '1px solid #22202b', paddingTop: 8, fontFamily: 'var(--font-mono)', fontSize: 10, color: '#6c6a5e' }}>
                  {e.date} · {era?.label}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}

/* ─── CTA ────────────────────────────────────────────────────────────────── */
function CTA() {
  return (
    <section style={{ padding: '72px 32px', background: '#05040a', borderTop: '2px solid #ebe7da' }}>
      <div style={{ maxWidth: 1240, margin: '0 auto', display: 'grid', gridTemplateColumns: '1fr auto', gap: 40, alignItems: 'center' }}>
        <div>
          <div style={{ fontFamily: 'var(--font-mono)', fontSize: 11, fontWeight: 700, letterSpacing: '0.14em', color: '#6c6a5e', textTransform: 'uppercase', marginBottom: 12 }}>
            // the build continues
          </div>
          <h2 style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 44, letterSpacing: '-0.02em', color: '#ebe7da', margin: '0 0 12px', maxWidth: 640 }}>
            This is a working runtime,<br/>not a finished product.
          </h2>
          <p style={{ fontFamily: 'var(--font-mono)', fontSize: 14, lineHeight: 1.65, color: '#6c6a5e', margin: '0 0 28px', maxWidth: 560 }}>
            The journal is public memory. The runtime is open source. If you experiment, write a spec, or find a failure worth logging — that belongs here too.
          </p>
          <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap' }}>
            <button style={{
              fontFamily: 'var(--font-mono)', fontWeight: 700, fontSize: 13,
              letterSpacing: '0.06em', textTransform: 'uppercase',
              padding: '12px 20px', border: '2px solid #ebe7da',
              background: '#ff48a1', color: '#05040a',
              boxShadow: '4px 4px 0 0 #ff2e88', cursor: 'pointer',
            }}>Read the runtime →</button>
            <button style={{
              fontFamily: 'var(--font-mono)', fontWeight: 700, fontSize: 13,
              letterSpacing: '0.06em', textTransform: 'uppercase',
              padding: '12px 20px', border: '2px solid #34323f',
              background: 'transparent', color: '#a6a396',
              cursor: 'pointer',
            }}>github ↗</button>
            <button style={{
              fontFamily: 'var(--font-mono)', fontWeight: 700, fontSize: 13,
              letterSpacing: '0.06em', textTransform: 'uppercase',
              padding: '12px 20px', border: '2px solid #34323f',
              background: 'transparent', color: '#a6a396',
              cursor: 'pointer',
            }}>public artifacts ↗</button>
          </div>
          <div style={{ marginTop: 24, fontFamily: 'var(--font-mono)', fontSize: 11, color: '#34323f', lineHeight: 1.8 }}>
            <span style={{ color: '#3fe38d' }}>●</span> punk v0.4 · local runtime · experimental
            {'   '}
            <span style={{ color: '#ffc06b' }}>●</span> not production-ready
            {'   '}
            <span style={{ color: '#6c6a5e' }}>●</span> modules: later
          </div>
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 16 }}>
          <Porcupine size={150} />
          <div style={{
            fontFamily: 'var(--font-mono)', fontSize: 10, color: '#6c6a5e',
            textAlign: 'center', lineHeight: 1.7,
          }}>
            // deny-by-default<br/>
            // stay local<br/>
            // read the diff
          </div>
        </div>
      </div>
    </section>
  );
}

/* ─── NAV BAR ────────────────────────────────────────────────────────────── */
function NavBar() {
  return (
    <header style={{
      display: 'flex', alignItems: 'center', gap: 20,
      padding: '0 32px', height: 56,
      borderBottom: '1px solid #22202b',
      background: '#05040a',
      position: 'sticky', top: 0, zIndex: 200,
    }}>
      <a href="#" style={{ display: 'flex', alignItems: 'center', gap: 10, textDecoration: 'none', color: 'inherit' }}>
        <span style={{ fontFamily: 'var(--font-mono)', fontWeight: 700, background: '#0f0e0b', color: '#ff48a1', padding: '2px 6px', fontSize: 13, letterSpacing: '0.04em', border: '1px solid #34323f' }}>[//]</span>
        <span style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 17, letterSpacing: '-0.01em', color: '#ebe7da' }}>SpecPunk</span>
      </a>
      <nav style={{ display: 'flex', gap: 22, marginLeft: 24, fontFamily: 'var(--font-mono)', fontSize: 13 }}>
        {[['specs','#'],['runtime','#'],['stewardship','#'],['docs','#'],['journal','#journal']].map(([label, href]) => (
          <a key={label} href={href} style={{
            color: label === 'journal' ? '#ff48a1' : '#6c6a5e',
            textDecoration: label === 'journal' ? 'underline' : 'none',
            fontWeight: label === 'journal' ? 700 : 400,
            letterSpacing: label === 'journal' ? '0.04em' : 0,
          }}>{label}</a>
        ))}
      </nav>
      <div style={{ flex: 1 }} />
      <a href="#" style={{ fontFamily: 'var(--font-mono)', fontSize: 13, color: '#6c6a5e', textDecoration: 'none' }}>github ↗</a>
    </header>
  );
}

/* ─── HERO ───────────────────────────────────────────────────────────────── */
function Hero() {
  return (
    <section style={{
      borderBottom: '1px solid #22202b',
      background: '#05040a',
      backgroundImage: 'linear-gradient(#22202b 1px, transparent 1px), linear-gradient(90deg, #22202b 1px, transparent 1px)',
      backgroundSize: '40px 40px',
    }}>
      <div style={{ maxWidth: 1240, margin: '0 auto', padding: '64px 32px 56px', display: 'grid', gridTemplateColumns: '1fr auto', gap: 48, alignItems: 'end' }}>
        <div>
          {/* eyebrow */}
          <div style={{ display: 'flex', align: 'center', gap: 12, marginBottom: 16, flexWrap: 'wrap' }}>
            <span style={{
              fontFamily: 'var(--font-mono)', fontWeight: 700, fontSize: 10,
              letterSpacing: '0.14em', textTransform: 'uppercase',
              color: '#05040a', background: '#ff48a1',
              padding: '3px 9px 2px', display: 'inline-block',
              boxShadow: '2px 2px 0 0 #c7005f',
            }}>Journal</span>
            <span style={{ fontFamily: 'var(--font-mono)', fontSize: 11, color: '#6c6a5e', alignSelf: 'center' }}>// repo-tracked public memory</span>
          </div>

          {/* title */}
          <h1 style={{
            fontFamily: 'var(--font-display)', fontWeight: 700,
            fontSize: 72, lineHeight: 0.96, letterSpacing: '-0.03em',
            color: '#ebe7da', margin: '0 0 20px', maxWidth: 760,
          }}>
            The Road<br/>to <span style={{ color: '#ff48a1' }}>Punk</span>.
          </h1>

          {/* subtitle */}
          <p style={{
            fontFamily: 'var(--font-mono)', fontSize: 15, lineHeight: 1.65,
            color: '#a6a396', margin: '0 0 28px', maxWidth: 560,
          }}>
            A repo-tracked chronology of the experiments, failures, and systems that led to Punk. Not marketing copy. Public memory.
          </p>

          {/* state capsule */}
          <div style={{
            display: 'inline-grid', gridTemplateColumns: 'repeat(4, auto)',
            gap: 0, border: '1px solid #22202b',
          }}>
            {[
              { label: 'CURRENT', value: 'v0.4', color: '#3fe38d' },
              { label: 'STATUS', value: 'experimental', color: '#ffc06b' },
              { label: 'ERAS', value: '6', color: '#a6a396' },
              { label: 'ENTRIES', value: `${ENTRIES.length}`, color: '#a6a396' },
            ].map((item, i) => (
              <div key={i} style={{
                padding: '10px 16px',
                borderRight: i < 3 ? '1px solid #22202b' : 'none',
                background: i === 0 ? '#0a1f14' : 'transparent',
              }}>
                <div style={{ fontFamily: 'var(--font-mono)', fontSize: 9, fontWeight: 700, letterSpacing: '0.14em', color: '#6c6a5e', textTransform: 'uppercase', marginBottom: 3 }}>{item.label}</div>
                <div style={{ fontFamily: 'var(--font-mono)', fontSize: 14, fontWeight: 700, color: item.color }}>{item.value}</div>
              </div>
            ))}
          </div>
        </div>

        {/* mascot + receipt */}
        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end', gap: 16 }}>
          <Porcupine size={190} />
          {/* terminal receipt */}
          <div style={{
            background: '#000006', border: '1px solid #22202b',
            borderLeft: '3px solid #ff48a1',
            fontFamily: 'var(--font-mono)', fontSize: 11, lineHeight: 1.8,
            padding: '12px 16px', color: '#6c6a5e', width: 280,
          }}>
            <div style={{ color: '#34323f' }}>$ punk journal --status</div>
            <div><span style={{ color: '#3fe38d' }}>era:</span>       punk · v0.4</div>
            <div><span style={{ color: '#ffc06b' }}>stage:</span>     experimental</div>
            <div><span style={{ color: '#a6a396' }}>entries:</span>   {ENTRIES.length} logged</div>
            <div><span style={{ color: '#a6a396' }}>artifacts:</span> {ENTRIES.filter(e=>e.artifact).length} on shelf</div>
            <div><span style={{ color: '#ff6b62' }}>modules:</span>   later</div>
            <div><span style={{ color: '#3fe38d' }}>runtime:</span>   local-only</div>
          </div>
        </div>
      </div>
    </section>
  );
}

/* ─── TWEAKS PANEL ───────────────────────────────────────────────────────── */
const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "showArtifactsInline": true,
  "compactCards": false,
  "highlightSurvivors": true
}/*EDITMODE-END*/;

function TweaksPanel({ tweaks, setTweaks, visible }) {
  if (!visible) return null;
  return (
    <div style={{
      position: 'fixed', bottom: 24, right: 24, zIndex: 9999,
      background: '#11101a', border: '1px solid #34323f',
      borderTop: '2px solid #ff48a1',
      padding: '16px 18px', width: 240,
      boxShadow: '4px 4px 0 0 #ff2e88',
      fontFamily: 'var(--font-mono)',
    }}>
      <div style={{ fontSize: 11, fontWeight: 700, letterSpacing: '0.12em', color: '#ff48a1', textTransform: 'uppercase', marginBottom: 14 }}>Tweaks</div>
      {[
        { key: 'showArtifactsInline', label: 'Artifacts inline' },
        { key: 'compactCards', label: 'Compact cards' },
        { key: 'highlightSurvivors', label: 'Highlight survivors' },
      ].map(({ key, label }) => (
        <label key={key} style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 10, cursor: 'pointer' }}>
          <div onClick={() => {
            const next = { ...tweaks, [key]: !tweaks[key] };
            setTweaks(next);
            window.parent.postMessage({ type: '__edit_mode_set_keys', edits: next }, '*');
          }} style={{
            width: 28, height: 16, background: tweaks[key] ? '#ff48a1' : '#22202b',
            border: `1px solid ${tweaks[key] ? '#ff48a1' : '#34323f'}`,
            position: 'relative', cursor: 'pointer', flexShrink: 0,
            transition: 'background 0.16s ease',
          }}>
            <div style={{
              position: 'absolute', top: 2, left: tweaks[key] ? 13 : 2,
              width: 10, height: 10, background: '#ebe7da',
              transition: 'left 0.16s ease',
            }} />
          </div>
          <span style={{ fontSize: 12, color: '#a6a396' }}>{label}</span>
        </label>
      ))}
    </div>
  );
}

/* ─── MAIN APP ───────────────────────────────────────────────────────────── */
function App() {
  const allTypes = Object.keys(TYPE_CONFIG);
  const [activeEra, setActiveEra] = useState(() => {
    try { return localStorage.getItem('pj_era') || null; } catch { return null; }
  });
  const [activeTypes, setActiveTypes] = useState(allTypes);
  const [tweaks, setTweaks] = useState(TWEAK_DEFAULTS);
  const [tweakVisible, setTweakVisible] = useState(false);

  // persist era
  useEffect(() => {
    try { localStorage.setItem('pj_era', activeEra || ''); } catch {}
  }, [activeEra]);

  // tweaks protocol
  useEffect(() => {
    const handler = (e) => {
      if (e.data?.type === '__activate_edit_mode') setTweakVisible(true);
      if (e.data?.type === '__deactivate_edit_mode') setTweakVisible(false);
    };
    window.addEventListener('message', handler);
    window.parent.postMessage({ type: '__edit_mode_available' }, '*');
    return () => window.removeEventListener('message', handler);
  }, []);

  const handleEraClick = useCallback((eraId) => {
    setActiveEra(prev => prev === eraId ? null : eraId);
    if (eraId) {
      setTimeout(() => {
        const el = document.getElementById(`era-${eraId}`);
        if (el) { const y = el.getBoundingClientRect().top + window.scrollY - 120; window.scrollTo({ top: y, behavior: 'smooth' }); }
      }, 50);
    }
  }, []);

  const handleTypeToggle = useCallback((type) => {
    setActiveTypes(prev =>
      prev.includes(type)
        ? prev.length > 1 ? prev.filter(t => t !== type) : allTypes
        : [...prev, type]
    );
  }, []);

  // filter entries
  const filteredEntries = ENTRIES.filter(e =>
    (!activeEra || e.era === activeEra) &&
    activeTypes.includes(e.type)
  );

  const eraEntries = (eraId) => filteredEntries.filter(e => e.era === eraId);
  const visibleEras = activeEra ? ERAS.filter(e => e.id === activeEra) : ERAS;

  return (
    <div>
      <NavBar />
      <main id="journal">
        <Hero />
        <EraMap activeEra={activeEra} onEraClick={handleEraClick} />
        <FilterBar
          activeEra={activeEra}
          activeTypes={activeTypes}
          onEraChange={setActiveEra}
          onTypeToggle={handleTypeToggle}
          totalVisible={filteredEntries.length}
        />

        {/* timeline */}
        <div style={{ background: '#05040a', backgroundImage: 'linear-gradient(#0a0912 1px, transparent 1px)', backgroundSize: '40px 40px' }}>
          <div style={{ maxWidth: 1240, margin: '0 auto', padding: '48px 32px 32px' }}>
            {visibleEras.map(era => (
              <EraSection
                key={era.id}
                era={era}
                entries={eraEntries(era.id)}
                activeEra={activeEra}
              />
            ))}
            {filteredEntries.length === 0 && (
              <div style={{ fontFamily: 'var(--font-mono)', fontSize: 13, color: '#34323f', padding: '40px 0', textAlign: 'center' }}>
                // no entries match this filter
              </div>
            )}
          </div>
        </div>

        <SurvivalMatrix />
        <ArtifactShelf />
        <CTA />

        {/* footer */}
        <footer style={{ padding: '24px 32px', background: '#0f0e0b', borderTop: '1px solid #22202b' }}>
          <div style={{ maxWidth: 1240, margin: '0 auto', display: 'flex', justifyContent: 'space-between', fontFamily: 'var(--font-mono)', fontSize: 11, color: '#34323f' }}>
            <span>[//] SpecPunk · Journal · {new Date().getFullYear()}</span>
            <span>// local-first. always has been.</span>
          </div>
        </footer>
      </main>

      <TweaksPanel tweaks={tweaks} setTweaks={setTweaks} visible={tweakVisible} />
    </div>
  );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<App />);
